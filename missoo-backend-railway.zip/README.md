# MiSSoo API

Express API for the MiSSoo Tunisian e-commerce site. It stores customers, delivery addresses, products, stock and cash-on-delivery orders in MongoDB Atlas, and sends order confirmations with the WhatsApp Cloud API.

## Railway setup

1. Create a Railway service from this repository. Keep the service root directory empty because `package.json` is at the repository root.
2. Create a MongoDB Atlas cluster and copy its connection string to `MONGODB_URI`.
3. Add every variable documented in `.env.example` to Railway Variables.
4. Deploy the service, generate a public Railway domain and run `npm run seed` once.
5. Set `NEXT_PUBLIC_API_URL` on the frontend to the Railway URL.

Railway supplies `PORT` automatically. Do not commit a real `.env` file or paste credentials into GitHub; save secrets only in Railway Variables.

## WhatsApp template

Create an approved Meta WhatsApp template named `order_confirmation` with two body variables in this order: order number and total amount. Store the permanent access token and phone-number ID only in Railway Variables.

## Main API routes

- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/refresh`
- `GET/PATCH /api/customers/me`, `POST /api/customers/me/addresses`
- `GET /api/products`
- `POST /api/orders`, `GET /api/orders/mine`
- `/api/admin/*` for products, stock, customers, orders and statuses
