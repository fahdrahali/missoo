import crypto from "node:crypto";
import type { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { env } from "./config.js";
import { User } from "./models/User.js";

export type AuthRequest = Request & { user?: { id: string; role: "customer" | "admin" } };

export function createAccessToken(user: { id: string; role: string }) {
  return jwt.sign({ sub: user.id, role: user.role }, env.JWT_SECRET, { expiresIn: "15m" });
}
export function createRefreshToken(user: { id: string; role: string }) {
  return jwt.sign({ sub: user.id, role: user.role, type: "refresh" }, env.JWT_REFRESH_SECRET, { expiresIn: "7d" });
}
export function hashToken(token: string) { return crypto.createHash("sha256").update(token).digest("hex"); }

export async function optionalAuth(req: AuthRequest, _res: Response, next: NextFunction) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (!token) return next();
  try {
    const payload = jwt.verify(token, env.JWT_SECRET) as jwt.JwtPayload;
    req.user = { id: String(payload.sub), role: payload.role as "customer" | "admin" };
  } catch {}
  next();
}

export function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  optionalAuth(req, res, () => req.user ? next() : res.status(401).json({ message: "Authentication requise" }));
}
export function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  requireAuth(req, res, () => req.user?.role === "admin" ? next() : res.status(403).json({ message: "Accès administrateur requis" }));
}

export async function issueSession(user: any, res: Response) {
  const accessToken = createAccessToken({ id: user.id, role: user.role });
  const refreshToken = createRefreshToken({ id: user.id, role: user.role });
  user.refreshTokenHash = hashToken(refreshToken);
  await user.save();
  res.cookie("missoo_refresh", refreshToken, {
    httpOnly: true,
    secure: env.NODE_ENV === "production",
    sameSite: env.NODE_ENV === "production" ? "none" : "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
  return accessToken;
}

export async function userFromRefreshToken(token: string) {
  const payload = jwt.verify(token, env.JWT_REFRESH_SECRET) as jwt.JwtPayload;
  if (payload.type !== "refresh") throw new Error("Invalid token");
  return User.findById(payload.sub).select("+refreshTokenHash");
}
