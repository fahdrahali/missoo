import { Schema, model } from "mongoose";

export const ORDER_STATUSES = ["New", "Confirmed", "Shipped", "Delivered", "Cancelled"] as const;

const orderSchema = new Schema({
  orderNumber: { type: String, required: true, unique: true, index: true },
  customer: { type: Schema.Types.ObjectId, ref: "User", index: true },
  customerSnapshot: {
    fullName: { type: String, required: true },
    phone: { type: String, required: true },
    email: { type: String },
  },
  deliveryAddress: {
    governorate: { type: String, required: true },
    address: { type: String, required: true },
  },
  items: [{
    product: { type: Schema.Types.ObjectId, ref: "Product", required: true },
    slug: { type: String, required: true },
    title: { type: String, required: true },
    sku: { type: String, required: true },
    quantity: { type: Number, required: true, min: 1 },
    unitPrice: { type: Number, required: true, min: 0 },
    lineTotal: { type: Number, required: true, min: 0 },
  }],
  subtotal: { type: Number, required: true, min: 0 },
  deliveryFee: { type: Number, required: true, default: 7 },
  total: { type: Number, required: true, min: 0 },
  paymentMethod: { type: String, enum: ["cash_on_delivery"], default: "cash_on_delivery" },
  status: { type: String, enum: ORDER_STATUSES, default: "New", index: true },
  statusHistory: [{ status: { type: String, enum: ORDER_STATUSES }, changedAt: { type: Date, default: Date.now } }],
  notification: {
    channel: { type: String, enum: ["whatsapp"], default: "whatsapp" },
    status: { type: String, enum: ["pending", "sent", "failed"], default: "pending" },
    sentAt: Date,
    error: String,
  },
}, { timestamps: true });

export const Order = model("Order", orderSchema);
