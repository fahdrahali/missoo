import { Schema, model } from "mongoose";

const productSchema = new Schema({
  slug: { type: String, required: true, unique: true, index: true, trim: true },
  sku: { type: String, required: true, unique: true, index: true, trim: true },
  title: { type: String, required: true, trim: true },
  titleAr: { type: String, trim: true },
  description: { type: String, trim: true },
  descriptionAr: { type: String, trim: true },
  category: { type: String, required: true, index: true },
  price: { type: Number, required: true, min: 0 },
  stock: { type: Number, required: true, min: 0, default: 0 },
  images: { type: [String], default: [] },
  attributes: { type: Schema.Types.Mixed, default: {} },
  variants: [{
    sku: { type: String, required: true },
    label: { type: String, required: true },
    price: { type: Number, min: 0 },
    stock: { type: Number, min: 0, default: 0 },
    attributes: { type: Schema.Types.Mixed, default: {} },
  }],
  active: { type: Boolean, default: true, index: true },
}, { timestamps: true });

export const Product = model("Product", productSchema);
