import { Schema, model } from "mongoose";

const addressSchema = new Schema({
  label: { type: String, trim: true, default: "Domicile" },
  governorate: { type: String, required: true, trim: true },
  address: { type: String, required: true, trim: true },
  isDefault: { type: Boolean, default: false },
}, { _id: true, timestamps: true });

const userSchema = new Schema({
  fullName: { type: String, required: true, trim: true },
  phone: { type: String, required: true, unique: true, index: true },
  email: { type: String, trim: true, lowercase: true, sparse: true, unique: true },
  passwordHash: { type: String, required: true, select: false },
  role: { type: String, enum: ["customer", "admin"], default: "customer", index: true },
  addresses: { type: [addressSchema], default: [] },
  refreshTokenHash: { type: String, select: false },
  active: { type: Boolean, default: true },
}, { timestamps: true });

userSchema.set("toJSON", { transform: (_doc, ret) => { const safe = ret as Record<string, unknown>; delete safe.passwordHash; delete safe.refreshTokenHash; return safe; } });
export const User = model("User", userSchema);
