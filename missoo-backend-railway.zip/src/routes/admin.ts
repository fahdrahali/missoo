import { Router } from "express";
import { z } from "zod";
import { requireAdmin } from "../auth.js";
import { Order, ORDER_STATUSES } from "../models/Order.js";
import { Product } from "../models/Product.js";
import { User } from "../models/User.js";

const router = Router();
router.use(requireAdmin);

router.get("/overview", async (_req, res) => {
  const [products, customers, orders, lowStock, recentOrders] = await Promise.all([
    Product.countDocuments(), User.countDocuments({ role: "customer" }), Order.countDocuments(), Product.countDocuments({ stock: { $lte: 5 }, active: true }), Order.find().sort({ createdAt: -1 }).limit(6).lean(),
  ]);
  return res.json({ counts: { products, customers, orders, lowStock }, recentOrders });
});
router.get("/products", async (_req, res) => res.json(await Product.find().sort({ updatedAt: -1 }).lean()));
router.post("/products", async (req, res) => {
  const parsed = z.object({ slug: z.string().min(2), sku: z.string().min(2), title: z.string().min(2), titleAr: z.string().optional(), category: z.string().min(2), price: z.number().min(0), stock: z.number().int().min(0), images: z.array(z.string()).default([]), attributes: z.record(z.string(), z.unknown()).default({}), active: z.boolean().default(true) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Produit invalide", issues: parsed.error.issues });
  return res.status(201).json(await Product.create(parsed.data));
});
router.patch("/products/:id", async (req, res) => {
  const allowed = z.object({ title: z.string().min(2).optional(), titleAr: z.string().optional(), category: z.string().min(2).optional(), price: z.number().min(0).optional(), stock: z.number().int().min(0).optional(), active: z.boolean().optional(), attributes: z.record(z.string(), z.unknown()).optional() }).safeParse(req.body);
  if (!allowed.success) return res.status(400).json({ message: "Produit invalide" });
  const product = await Product.findByIdAndUpdate(req.params.id, allowed.data, { new: true, runValidators: true });
  return product ? res.json(product) : res.status(404).json({ message: "Produit introuvable" });
});
router.delete("/products/:id", async (req, res) => {
  const product = await Product.findByIdAndUpdate(req.params.id, { active: false }, { new: true });
  return product ? res.status(204).send() : res.status(404).json({ message: "Produit introuvable" });
});
router.get("/customers", async (_req, res) => res.json(await User.find({ role: "customer" }).sort({ createdAt: -1 }).lean()));
router.get("/orders", async (req, res) => {
  const filter = typeof req.query.status === "string" && ORDER_STATUSES.includes(req.query.status as any) ? { status: req.query.status } : {};
  return res.json(await Order.find(filter).sort({ createdAt: -1 }).lean());
});
router.patch("/orders/:id/status", async (req, res) => {
  const parsed = z.object({ status: z.enum(ORDER_STATUSES) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Statut invalide" });
  const order = await Order.findByIdAndUpdate(req.params.id, { $set: { status: parsed.data.status }, $push: { statusHistory: { status: parsed.data.status, changedAt: new Date() } } }, { new: true, runValidators: true });
  return order ? res.json(order) : res.status(404).json({ message: "Commande introuvable" });
});

export default router;
