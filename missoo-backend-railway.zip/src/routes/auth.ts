import { Router } from "express";
import argon2 from "argon2";
import { z } from "zod";
import { hashToken, issueSession, userFromRefreshToken } from "../auth.js";
import { User } from "../models/User.js";

const router = Router();
const phone = z.string().regex(/^[234579]\d{7}$/, "Numéro tunisien invalide");

router.post("/register", async (req, res) => {
  const result = z.object({
    fullName: z.string().trim().min(2),
    phone,
    email: z.union([z.string().email(), z.literal("")]).optional(),
    password: z.string().min(8),
  }).safeParse(req.body);
  if (!result.success) return res.status(400).json({ message: "Informations invalides", issues: result.error.issues });
  const existing = await User.findOne({ $or: [{ phone: result.data.phone }, ...(result.data.email ? [{ email: result.data.email.toLowerCase() }] : [])] });
  if (existing) return res.status(409).json({ message: "Ce téléphone ou cet e-mail est déjà utilisé" });
  const user = await User.create({
    fullName: result.data.fullName,
    phone: result.data.phone,
    email: result.data.email || undefined,
    passwordHash: await argon2.hash(result.data.password),
  });
  const accessToken = await issueSession(user, res);
  return res.status(201).json({ accessToken, user: user.toJSON() });
});

router.post("/login", async (req, res) => {
  const result = z.object({ identity: z.string().trim().min(3), password: z.string().min(1) }).safeParse(req.body);
  if (!result.success) return res.status(400).json({ message: "Informations invalides" });
  const identity = result.data.identity.toLowerCase();
  const user = await User.findOne({ $or: [{ phone: identity }, { email: identity }] }).select("+passwordHash");
  if (!user || !user.active || !await argon2.verify(user.passwordHash, result.data.password)) return res.status(401).json({ message: "Identifiants incorrects" });
  const accessToken = await issueSession(user, res);
  return res.json({ accessToken, user: user.toJSON() });
});

router.post("/refresh", async (req, res) => {
  const token = req.cookies?.missoo_refresh;
  if (!token) return res.status(401).json({ message: "Session expirée" });
  try {
    const user = await userFromRefreshToken(token);
    if (!user || user.refreshTokenHash !== hashToken(token) || !user.active) return res.status(401).json({ message: "Session expirée" });
    const accessToken = await issueSession(user, res);
    return res.json({ accessToken, user: user.toJSON() });
  } catch { return res.status(401).json({ message: "Session expirée" }); }
});

router.post("/logout", async (req, res) => {
  const token = req.cookies?.missoo_refresh;
  if (token) {
    try { const user = await userFromRefreshToken(token); if (user) { user.refreshTokenHash = undefined; await user.save(); } } catch {}
  }
  res.clearCookie("missoo_refresh", { sameSite: "none", secure: true });
  return res.status(204).send();
});

export default router;
