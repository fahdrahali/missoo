import { Router } from "express";
import { z } from "zod";
import { type AuthRequest, requireAuth } from "../auth.js";
import { User } from "../models/User.js";

const router = Router();
router.use(requireAuth);

router.get("/me", async (req: AuthRequest, res) => {
  const user = await User.findById(req.user!.id);
  if (!user) return res.status(404).json({ message: "Client introuvable" });
  return res.json(user);
});

router.patch("/me", async (req: AuthRequest, res) => {
  const result = z.object({ fullName: z.string().trim().min(2).optional(), email: z.union([z.string().email(), z.literal("")]).optional() }).safeParse(req.body);
  if (!result.success) return res.status(400).json({ message: "Profil invalide" });
  const user = await User.findByIdAndUpdate(req.user!.id, { ...result.data, email: result.data.email || undefined }, { new: true, runValidators: true });
  return res.json(user);
});

router.post("/me/addresses", async (req: AuthRequest, res) => {
  const result = z.object({ label: z.string().trim().min(1).default("Domicile"), governorate: z.string().trim().min(2), address: z.string().trim().min(5), isDefault: z.boolean().default(false) }).safeParse(req.body);
  if (!result.success) return res.status(400).json({ message: "Adresse invalide" });
  const user = await User.findById(req.user!.id);
  if (!user) return res.status(404).json({ message: "Client introuvable" });
  if (result.data.isDefault) user.addresses.forEach((item: any) => { item.isDefault = false; });
  user.addresses.push(result.data as any);
  await user.save();
  return res.status(201).json(user.addresses);
});

router.delete("/me/addresses/:addressId", async (req: AuthRequest, res) => {
  const user = await User.findById(req.user!.id);
  if (!user) return res.status(404).json({ message: "Client introuvable" });
  user.addresses.pull({ _id: req.params.addressId });
  await user.save();
  return res.status(204).send();
});

export default router;
