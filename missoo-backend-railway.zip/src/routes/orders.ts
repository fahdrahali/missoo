import { Router } from "express";
import mongoose from "mongoose";
import { z } from "zod";
import { type AuthRequest, optionalAuth, requireAuth } from "../auth.js";
import { Order } from "../models/Order.js";
import { Product } from "../models/Product.js";
import { User } from "../models/User.js";
import { sendOrderConfirmation } from "../whatsapp.js";

const router = Router();
const orderInput = z.object({
  customer: z.object({ fullName: z.string().trim().min(2), phone: z.string().regex(/^[234579]\d{7}$/), email: z.union([z.string().email(), z.literal("")]).optional() }),
  deliveryAddress: z.object({ governorate: z.string().trim().min(2), address: z.string().trim().min(5) }),
  items: z.array(z.object({ slug: z.string().trim().min(1), quantity: z.number().int().min(1).max(20) })).min(1),
});

router.post("/", optionalAuth, async (req: AuthRequest, res) => {
  const parsed = orderInput.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Commande invalide", issues: parsed.error.issues });
  const session = await mongoose.startSession();
  try {
    let created: any;
    await session.withTransaction(async () => {
      const slugs = parsed.data.items.map((item) => item.slug);
      const products = await Product.find({ slug: { $in: slugs }, active: true }).session(session);
      if (products.length !== new Set(slugs).size) throw new Error("Un produit n’est plus disponible");
      const items = parsed.data.items.map((line) => {
        const product = products.find((item) => item.slug === line.slug)!;
        if (product.stock < line.quantity) throw new Error(`Stock insuffisant pour ${product.title}`);
        return { product: product._id, slug: product.slug, title: product.title, sku: product.sku, quantity: line.quantity, unitPrice: product.price, lineTotal: product.price * line.quantity };
      });
      const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);
      const orderNumber = `MS-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
      [created] = await Order.create([{ orderNumber, customer: req.user?.id, customerSnapshot: parsed.data.customer, deliveryAddress: parsed.data.deliveryAddress, items, subtotal, deliveryFee: 7, total: subtotal + 7, statusHistory: [{ status: "New" }] }], { session });
      await Promise.all(items.map((line) => Product.updateOne({ _id: line.product, stock: { $gte: line.quantity } }, { $inc: { stock: -line.quantity } }, { session })));
      if (req.user) {
        const user = await User.findById(req.user.id).session(session);
        if (user) {
          user.fullName = parsed.data.customer.fullName;
          if (parsed.data.customer.email) user.email = parsed.data.customer.email;
          const exists = user.addresses.some((item: any) => item.governorate === parsed.data.deliveryAddress.governorate && item.address === parsed.data.deliveryAddress.address);
          if (!exists) user.addresses.push({ ...parsed.data.deliveryAddress, label: "Livraison", isDefault: user.addresses.length === 0 } as any);
          await user.save({ session });
        }
      }
    });
    try {
      await sendOrderConfirmation({ phone: parsed.data.customer.phone, orderNumber: created.orderNumber, total: created.total });
      created.notification = { channel: "whatsapp", status: "sent", sentAt: new Date() };
    } catch (error) {
      created.notification = { channel: "whatsapp", status: "failed", error: error instanceof Error ? error.message : "Unknown error" };
    }
    await created.save();
    return res.status(201).json({ orderNumber: created.orderNumber, status: created.status, total: created.total, notification: created.notification.status });
  } catch (error) {
    return res.status(409).json({ message: error instanceof Error ? error.message : "Impossible de créer la commande" });
  } finally { await session.endSession(); }
});

router.get("/mine", requireAuth, async (req: AuthRequest, res) => {
  const orders = await Order.find({ customer: req.user!.id }).sort({ createdAt: -1 }).lean();
  return res.json(orders);
});

export default router;
