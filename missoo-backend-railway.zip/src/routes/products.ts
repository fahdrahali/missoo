import { Router } from "express";
import { Product } from "../models/Product.js";

const router = Router();
router.get("/", async (req, res) => {
  const filter: Record<string, unknown> = { active: true };
  if (typeof req.query.category === "string" && req.query.category) filter.category = req.query.category;
  const products = await Product.find(filter).sort({ createdAt: -1 }).lean();
  return res.json(products);
});
router.get("/:slug", async (req, res) => {
  const product = await Product.findOne({ slug: req.params.slug, active: true }).lean();
  return product ? res.json(product) : res.status(404).json({ message: "Produit introuvable" });
});
export default router;
