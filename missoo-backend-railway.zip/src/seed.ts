import "dotenv/config";
import argon2 from "argon2";
import { connectDatabase } from "./db.js";
import { Product } from "./models/Product.js";
import { User } from "./models/User.js";

const products = [
  { slug: "ecouteurs-pro-anc", sku: "MS-HEAD-001", title: "Écouteurs sans fil Pro ANC", titleAr: "سماعات لاسلكية Pro بخاصية عزل الضوضاء", category: "High-Tech", price: 189, stock: 25, images: ["/products/headphones-triptych.png"], attributes: { bluetooth: "5.3", batteryHours: 32 } },
  { slug: "aspirateur-2-en-1", sku: "MS-HOME-001", title: "Aspirateur sans fil 2-en-1", titleAr: "مكنسة لاسلكية 2 في 1", category: "Maison & Jardin", price: 399, stock: 18, images: ["/products/vacuum-triptych.png"], attributes: { type: "2-en-1", washableFilter: true } },
  { slug: "smart-tv-55-4k", sku: "MS-TV-001", title: "Smart TV 55 pouces 4K UHD", titleAr: "تلفاز ذكي 55 بوصة بدقة 4K", category: "High-Tech", price: 1899, stock: 8, images: ["/products/tv-triptych.png"], attributes: { screenSize: 55, resolution: "4K UHD", hdmiPorts: 3 } },
  { slug: "machine-cafe-automatique", sku: "MS-COFFEE-001", title: "Machine à café automatique", titleAr: "آلة قهوة أوتوماتيكية", category: "Électroménager", price: 749, stock: 12, images: ["/products/coffee-triptych.png"], attributes: { grinder: true, automaticCleaning: true } },
  { slug: "baskets-urbaines", sku: "MS-SHOE-001", title: "Baskets urbaines unisexes", titleAr: "حذاء رياضي عصري للجميع", category: "Sport", price: 129, stock: 35, images: ["/products/shoes-triptych.png"], attributes: { sizes: [36,37,38,39,40,41,42,43,44], breathable: true } },
];

await connectDatabase();
for (const product of products) await Product.updateOne({ slug: product.slug }, { $set: product, $setOnInsert: { active: true } }, { upsert: true });
const adminPhone = process.env.ADMIN_PHONE;
const adminPassword = process.env.ADMIN_PASSWORD;
if (adminPhone && adminPassword) {
  await User.updateOne({ phone: adminPhone }, { $set: { fullName: process.env.ADMIN_NAME || "MiSSoo Admin", role: "admin", active: true, passwordHash: await argon2.hash(adminPassword) } }, { upsert: true });
}
console.log("MiSSoo seed completed");
process.exit(0);
