import { env } from "./config.js";

function normalizeTunisianPhone(phone: string) {
  const digits = phone.replace(/\D/g, "");
  return digits.startsWith("216") ? digits : `216${digits}`;
}

export async function sendOrderConfirmation(input: { phone: string; orderNumber: string; total: number }) {
  if (!env.WHATSAPP_ACCESS_TOKEN || !env.WHATSAPP_PHONE_NUMBER_ID) {
    throw new Error("WhatsApp Cloud API is not configured");
  }
  const response = await fetch(`https://graph.facebook.com/${env.WHATSAPP_GRAPH_API_VERSION}/${env.WHATSAPP_PHONE_NUMBER_ID}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${env.WHATSAPP_ACCESS_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: normalizeTunisianPhone(input.phone),
      type: "template",
      template: {
        name: env.WHATSAPP_TEMPLATE_NAME,
        language: { code: env.WHATSAPP_TEMPLATE_LANGUAGE },
        components: [{ type: "body", parameters: [
          { type: "text", text: input.orderNumber },
          { type: "text", text: `${input.total.toFixed(3)} TND` },
        ] }],
      },
    }),
  });
  if (!response.ok) throw new Error(`WhatsApp API returned ${response.status}`);
}
